# This file is a part of Julia. License is MIT: https://julialang.org/license

using Test
# Check that the fallback test set throws immediately
@test 1 == 2
