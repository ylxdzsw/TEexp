# This file is a part of Julia. License is MIT: https://julialang.org/license

module PkgTests

include("pkg.jl")
include("resolve.jl")

end # module
