# This file is a part of Julia. License is MIT: https://julialang.org/license

using UnregisteredWithoutProject
using Test

@test f(2) == 2
